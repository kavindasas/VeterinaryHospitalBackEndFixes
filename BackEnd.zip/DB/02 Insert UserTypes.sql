USE [VeteDB]
GO

INSERT INTO [dbo].[UserType]
           ([Description])
     VALUES
           ('Doctor'),('Clinic Staff'),('Dog Owner')
GO


