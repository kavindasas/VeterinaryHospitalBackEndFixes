﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BackEnd.Models;
using BackEnd.Service;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BackEnd.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [DisableCors]
    public class OwnerController : ControllerBase
    {
     
        // GET api/values/5
        [HttpGet("{id}")]
        public Owner Get(int id)
        {
            OwnerService ownerService = new OwnerService();
            return ownerService.GetOwner(id);
        }

        // POST api/values
        [Route("reg")]
        [HttpPost]
        public Cookie Reg([FromBody] Owner owner)
        {
            OwnerService ownerService = new OwnerService();
            return ownerService.AddOwner(owner);
        }

        [Route("login")]
        [HttpPost]
        public Cookie Login([FromBody] Login owner)
        {
            OwnerService ownerService = new OwnerService();
            return ownerService.Login(owner);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Owner owner)
        {
        }
    }
}