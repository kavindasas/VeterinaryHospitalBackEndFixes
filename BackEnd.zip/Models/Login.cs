﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BackEnd.Models
{
    public class Login
    {
        public string RegNo { get; set; }
        public string PassWord { get; set; }
    }
}
